#%matplotlib inline
import sdf
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
import numpy as np
#from numpy import ma
from matplotlib import colors, ticker, cm
#from matplotlib.mlab import bivariate_normal
from optparse import OptionParser
import os
#import scipy.integrate as integrate
#import scipy.special as special
#from scipy.special import kv
  
if __name__ == "__main__":
  print ('This is main of module "test2d.py"')
  ######## Constant defined here ########
  pi        =     3.1415926535897932384626
  q0        =     1.602176565e-19 # C
  m0        =     9.10938291e-31  # kg
  v0        =     2.99792458e8    # m/s^2
  kb        =     1.3806488e-23   # J/K
  mu0       =     4.0e-7*np.pi       # N/A^2
  epsilon0  =     8.8541878176203899e-12 # F/m
  h_planck  =     6.62606957e-34  # J s
  wavelength=     1.0e-6
  frequency =     v0*2*pi/wavelength

  exunit    =     m0*v0*frequency/q0
  bxunit    =     m0*frequency/q0
  denunit    =     frequency**2*epsilon0*m0/q0**2
  jalf      =     4*np.pi*epsilon0*m0*v0**3/q0/wavelength**2
  print('electric field unit: '+str(exunit))
  print('magnetic field unit: '+str(bxunit))
  print('density unit nc: '+str(denunit))

  font = {'family' : 'monospace',
          'color'  : 'black',
          'weight' : 'normal',
          'size'   : 32,
          }

  font_size=32
  font_size2=24
  marker_size = 0.03

##below is for norm colorbar
  class MidpointNormalize(colors.Normalize):
    def __init__(self, vmin=None, vmax=None, midpoint=None, clip=False):
        self.midpoint = midpoint
        colors.Normalize.__init__(self, vmin, vmax, clip)

    def __call__(self, value, clip=None):
        # I'm ignoring masked values and all kinds of edge cases to make a
        # simple example...
        x, y = [self.vmin, self.midpoint, self.vmax], [0, 0.5, 1]
        return np.ma.masked_array(np.interp(value, x, y))
##end for norm colorbar####

  def pxpy_to_energy(gamma, weight):
      binsize = 200
      en_grid = np.linspace(0,1000,200)
      en_bin  = np.linspace(0,1000,201)
      en_value = np.zeros_like(en_grid)
      for i in range(binsize):
        en_value[i] = sum(weight[ (en_bin[i]<=gamma) & (gamma<en_bin[i+1]) ])/(en_bin[-1]-en_bin[-2])
      return (en_grid, en_value)

  def spin_to_theta(sz, theta):
      binsize = 60
      en_grid = np.linspace(-60,60,binsize)
      en_bin  = np.linspace(-60,60,binsize+1)
      en_value = np.zeros_like(en_grid)
      for i in range(binsize):
        en_value[i] = np.sum(sz[ (en_bin[i]<=theta) & (theta<en_bin[i+1]) ])/np.size(sz[ (en_bin[i]<=theta) & (theta<en_bin[i+1]) ])
      return (en_grid, en_value)


  def num_to_theta(ww,theta):
      binsize = 60
      en_grid = np.linspace(-60,60,binsize)
      en_bin  = np.linspace(-60,60,binsize+1)
      en_value = np.zeros_like(en_grid)
      for i in range(binsize):
        en_value[i] = np.sum(ww[ (en_bin[i]<=theta) & (theta<en_bin[i+1]) ])/(en_bin[-1]-en_bin[-2])
      return (en_grid, en_value)



  upper = matplotlib.cm.rainbow(np.arange(256))
  lower = np.ones((int(256/4),4))
  for i in range(3):
      lower[:,i] = np.linspace(1, upper[0,i], lower.shape[0])
  cmap = np.vstack(( lower, upper ))
  mycolor_rainbow = matplotlib.colors.ListedColormap(cmap, name='myColorMap', N=cmap.shape[0])


  from_path_l = ['./Data/']
  for i in range(np.size(from_path_l)):
      from_path = from_path_l[i]
      ######### Parameter you should set ###########
      start   =  4  # start time
      stop    =  4  # end time
      step    =  1  # the interval or step
    
      ######### Script code drawing figure ################
      for n in range(start,stop+step,step):
        #### header data ####
        data = sdf.read(from_path+'track'+str(n).zfill(4)+".sdf",dict=True)
        time=data['Header']['time']
        print(data.keys())
        print('reading',from_path+'track'+str(n).zfill(4)+".sdf")
        ee_x  = data['Grid/Particles/subset_trace_e/e_s'].data[0]/1e-6
        ee_y  = data['Grid/Particles/subset_trace_e/e_s'].data[1]/1e-6
    #    ee_z  = data['Grid/Particles/subset_trace_e/e_s'].data[2]/1e-6
        ee_px = data['Particles/Px/subset_trace_e/e_s'].data/(m0*v0)
        ee_py = data['Particles/Py/subset_trace_e/e_s'].data/(m0*v0)
        ee_pz = data['Particles/Pz/subset_trace_e/e_s'].data/(m0*v0)
        ee_gg = (ee_px**2+ee_py**2+ee_pz**2+1.0)**0.5
        ee_theta = np.arctan(ee_py/ee_px)/np.pi*180
        
    
        ee_sx = data['Particles/Sx/subset_trace_e/e_s'].data
        ee_sy = data['Particles/Sy/subset_trace_e/e_s'].data
        ee_sz = data['Particles/Sz/subset_trace_e/e_s'].data
    
        ee_ww = data['Particles/Weight/subset_trace_e/e_s'].data
    
        en_th = 1000
    
        plt.subplot(2,4,1)
        condition1=(ee_gg>en_th)
        if np.size(condition1) > 0:
    #        Q=plt.quiver(ion_y[condition1], ion_z[condition1], sy/(sy**2+sz**2)**0.5, sz/(sy**2+sz**2)**0.5, pivot='mid', units='inches')
            plt.scatter(ee_x[condition1], ee_y[condition1], c=ee_sz[condition1], cmap='bwr', norm=colors.Normalize(vmin=-1.0,vmax=1.0), s=marker_size*100, marker='.',alpha=0.8,zorder=3,lw=0)
            cbar=plt.colorbar(ticks=[-1,0,1],pad=0.01)
    #  cbar.ax.set_yticklabels(cbar.ax.get_yticklabels(), fontsize=20)
            cbar.ax.tick_params(labelsize=font_size2)
            cbar.set_label(r'$s_z$',fontdict=font)
    #        qk = plt.quiverkey(Q, 0.9, 0.9, 0.1, r'$s$', labelpos='E', coordinates='figure')
    #        plt.scatter(ion_y[condition1],ion_z[condition1], color='r', s=1)
            plt.xlim(-2,38)
            plt.ylim(-8,8)
            plt.xlabel('$x\ [\mu m]$',fontdict=font)
            plt.ylabel('$y\ [\mu m]$',fontdict=font)
            plt.xticks(fontsize=font_size);
            plt.yticks(fontsize=font_size);
            plt.title('t='+str(round(time/1.0e-15,0))+' fs',fontdict=font)
    
        plt.subplot(2,4,2)
        condition1=(ee_gg>en_th)
        if np.size(condition1) > 0:
    #        Q=plt.quiver(ion_y[condition1], ion_z[condition1], sy/(sy**2+sz**2)**0.5, sz/(sy**2+sz**2)**0.5, pivot='mid', units='inches')
            plt.scatter(ee_x[condition1], ee_y[condition1], c=ee_sy[condition1], cmap='bwr', norm=colors.Normalize(vmin=-1.0,vmax=1.0), s=marker_size*100, marker='.',alpha=0.8,zorder=3,lw=0)
            cbar=plt.colorbar(ticks=[-1,0,1],pad=0.01)
    #  cbar.ax.set_yticklabels(cbar.ax.get_yticklabels(), fontsize=20)
            cbar.ax.tick_params(labelsize=font_size2)
            cbar.set_label(r'$s_y$',fontdict=font)
    #        qk = plt.quiverkey(Q, 0.9, 0.9, 0.1, r'$s$', labelpos='E', coordinates='figure')
    #        plt.scatter(ion_y[condition1],ion_z[condition1], color='r', s=1)
            plt.xlim(-2,38)
            plt.ylim(-8,8)
            plt.xlabel('$x\ [\mu m]$',fontdict=font)
            plt.ylabel('$y\ [\mu m]$',fontdict=font)
            plt.xticks(fontsize=font_size);
            plt.yticks(fontsize=font_size);
            plt.title('t='+str(round(time/1.0e-15,0))+' fs',fontdict=font)
    
        plt.subplot(2,4,3)
        condition1=(ee_gg>en_th)
        if np.size(condition1) > 0:
    #        Q=plt.quiver(ion_y[condition1], ion_z[condition1], sy/(sy**2+sz**2)**0.5, sz/(sy**2+sz**2)**0.5, pivot='mid', units='inches')
            plt.scatter(ee_x[condition1], ee_y[condition1], c=ee_sx[condition1], cmap='bwr', norm=colors.Normalize(vmin=-1.0,vmax=1.0), s=marker_size*100, marker='.',alpha=0.8,zorder=3,lw=0)
            cbar=plt.colorbar(ticks=[-1,0,1],pad=0.01)
    #  cbar.ax.set_yticklabels(cbar.ax.get_yticklabels(), fontsize=20)
            cbar.ax.tick_params(labelsize=font_size2)
            cbar.set_label(r'$s_x$',fontdict=font)
    #        qk = plt.quiverkey(Q, 0.9, 0.9, 0.1, r'$s$', labelpos='E', coordinates='figure')
    #        plt.scatter(ion_y[condition1],ion_z[condition1], color='r', s=1)
            plt.xlim(-2,38)
            plt.ylim(-8,8)
            plt.xlabel('$x\ [\mu m]$',fontdict=font)
            plt.ylabel('$y\ [\mu m]$',fontdict=font)
            plt.xticks(fontsize=font_size);
            plt.yticks(fontsize=font_size);
            plt.title('t='+str(round(time/1.0e-15,0))+' fs',fontdict=font)
    
        plt.subplot(2,4,4)
        condition1=(ee_gg>en_th)
        if np.size(condition1) > 0:
    #        Q=plt.quiver(ion_y[condition1], ion_z[condition1], sy/(sy**2+sz**2)**0.5, sz/(sy**2+sz**2)**0.5, pivot='mid', units='inches')
            plt.scatter(ee_x[condition1], ee_y[condition1], c=ee_gg[condition1], cmap='rainbow', norm=colors.Normalize(vmin=0,vmax=2000), s=marker_size*100, marker='.',alpha=0.8,zorder=3,lw=0)
            cbar=plt.colorbar(ticks=[0,1000,2000],pad=0.01)
    #  cbar.ax.set_yticklabels(cbar.ax.get_yticklabels(), fontsize=20)
            cbar.ax.tick_params(labelsize=font_size2)
            cbar.set_label(r'$\gamma_e$',fontdict=font)
    #        qk = plt.quiverkey(Q, 0.9, 0.9, 0.1, r'$s$', labelpos='E', coordinates='figure')
    #        plt.scatter(ion_y[condition1],ion_z[condition1], color='r', s=1)
            plt.xlim(-2,38)
            plt.ylim(-8,8)
            plt.xlabel('$x\ [\mu m]$',fontdict=font)
            plt.ylabel('$y\ [\mu m]$',fontdict=font)
            plt.xticks(fontsize=font_size);
            plt.yticks(fontsize=font_size);
            plt.title('t='+str(round(time/1.0e-15,0))+' fs',fontdict=font)
    
        plt.subplot(2,4,5)
        condition1=(ee_gg>en_th)
        if np.size(condition1) > 0:
    #        Q=plt.quiver(ion_y[condition1], ion_z[condition1], sy/(sy**2+sz**2)**0.5, sz/(sy**2+sz**2)**0.5, pivot='mid', units='inches')
            plt.scatter(ee_y[condition1], ee_theta[condition1], c=ee_sz[condition1], cmap='bwr', norm=colors.Normalize(vmin=-1.0,vmax=1.0), s=marker_size*200, marker='.',alpha=0.8,zorder=3,lw=0)
            cbar=plt.colorbar(ticks=[-1,0,1],pad=0.01)
    #  cbar.ax.set_yticklabels(cbar.ax.get_yticklabels(), fontsize=20)
            cbar.ax.tick_params(labelsize=font_size2)
            cbar.set_label(r'$s_z$',fontdict=font)
    #        qk = plt.quiverkey(Q, 0.9, 0.9, 0.1, r'$s$', labelpos='E', coordinates='figure')
    #        plt.scatter(ion_y[condition1],ion_z[condition1], color='r', s=1)
            plt.xlim(-5,5)
            plt.ylim(-60,60)
            plt.xlabel('$y\ [\mu m]$',fontdict=font)
            plt.ylabel(r'$\theta_y\ [^\circ]$',fontdict=font)
            plt.xticks(fontsize=font_size);
            plt.yticks(fontsize=font_size);
            plt.title('t='+str(round(time/1.0e-15,0))+' fs',fontdict=font)
    
        plt.subplot(2,4,6)
        condition1=(ee_gg>en_th)
        if np.size(condition1) > 0:
            grid_theta,ave_sz = spin_to_theta(ee_sz[condition1], ee_theta[condition1])
    #        Q=plt.quiver(ion_y[condition1], ion_z[condition1], sy/(sy**2+sz**2)**0.5, sz/(sy**2+sz**2)**0.5, pivot='mid', units='inches')
            plt.plot(grid_theta,ave_sz,color='tomato',linestyle='--',linewidth=2)
    #        qk = plt.quiverkey(Q, 0.9, 0.9, 0.1, r'$s$', labelpos='E', coordinates='figure')
    #        plt.scatter(ion_y[condition1],ion_z[condition1], color='r', s=1)
            plt.xlim(-60,60)
            plt.ylim(-1,1)
            plt.xlabel(r'$\theta_y\ [^\circ]$',fontdict=font)
            plt.ylabel(r'$\left<s_z\right>$',fontdict=font)
            plt.xticks(fontsize=font_size);
            plt.yticks(fontsize=font_size);
            plt.grid(linestyle='--', linewidth=0.4, color='grey')
            plt.title('energy_th gg>'+str(en_th),fontdict=font)
    
        plt.subplot(2,4,7)
        condition1=(ee_gg>en_th)
        if np.size(condition1) > 0:
            grid_theta,num_theta = num_to_theta(ee_ww[condition1], ee_theta[condition1])
    #        Q=plt.quiver(ion_y[condition1], ion_z[condition1], sy/(sy**2+sz**2)**0.5, sz/(sy**2+sz**2)**0.5, pivot='mid', units='inches')
            plt.plot(grid_theta,num_theta,color='gray',linestyle='--',linewidth=2)
    #        qk = plt.quiverkey(Q, 0.9, 0.9, 0.1, r'$s$', labelpos='E', coordinates='figure')
    #        plt.scatter(ion_y[condition1],ion_z[condition1], color='r', s=1)
            plt.xlim(-60,60)
    #        plt.ylim(-1,1)
            plt.xticks(fontsize=font_size);
            plt.yticks(fontsize=font_size);
            plt.xlabel(r'$\theta_y\ [^\circ]$',fontdict=font)
            plt.ylabel(r'$dN/d\theta$ [A.U.]',fontdict=font)
    
    
        plt.subplots_adjust(left=0.10, bottom=0.10, right=0.97, top=0.97, wspace=0.3, hspace=0.3)
    
    
        fig = plt.gcf()
        fig.set_size_inches(36, 14.)
        fig.savefig(to_path+'scatter_sz_'+str(n).zfill(4)+'.png',format='png',dpi=160)
        plt.close("all")
        print(to_path+'scatter_sz_'+str(n).zfill(4)+'.png')
    
