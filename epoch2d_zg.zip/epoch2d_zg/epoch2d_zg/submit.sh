#!/bin/bash
#SBATCH -J Ar_2d
##SBATCH -p cpu_2022
#SBATCH -p cpu_2020
##SBATCH -p fat3t
##SBATCH -p fat1t
#SBATCH -N 1
#SBATCH -n 40  #16 #64
#SBATCH -o job.%j.o
#SBATCH -e job.%j.e
#SBATCH --exclude=node1071,node1065,node1021,node1051

# cpu_2020: 64 cores per node; 192GB memory
# cpu_2022: 64 cores per node;
# fat1t: 56 cores per node;  1TB memory 
# fat3t: 160 cores per node; 3TB memory 

echo "SLURM_JOB_NODELIST=${SLURM_JOB_NODELIST}"
echo "SLURM_NODELIST=${SLURM_NODELIST}"

#module load mpi/openmpi/3.0.0/intel
export PATH=/public/software/mpi/openmpi/3.0.0/intel/bin:$PATH
export LD_LIBRARY_PATH=/public/software/mpi/openmpi/3.0.0/intel/lib:$LD_LIBRARY_PATH
export INCLUDE=/public/software/mpi/openmpi/3.0.0/intel/include:$INCLUDE

date

#export I_MPI_PMI_LIBRARY=/opt/gridview/slurm17/lib/libpmi.so
#export I_MPI_PMI_LIBRARY=/opt/gridview/slurm17/lib/libpmi2.so

#time srun --mpi=pmi2 ./fire_openmpi_slurm 960000
for SIMDIR in 'Ar_r05_a76'
do
  echo ./${SIMDIR} | srun --mpi=pmi2 ./bin/epoch2d
#  echo ./${SIMDIR} | srun --mpi=pmi2 ./bin_spin/epoch2d
done
date
